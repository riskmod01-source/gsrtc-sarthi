# GSRTC સારથિ & મિત્ર App

## Setup Steps

### 1. Firebase Setup
- Firebase Console માં જાઓ
- `google-services.json` download કરો
- `android/app/google-services.json` તરીકે upload કરો

### 2. AdMob Setup  
- AdMob Console માં App register કરો
- `AndroidManifest.xml` માં App ID replace કરો

### 3. Razorpay Setup
- Razorpay Dashboard પર Key ID લો
- `main.dart` માં `YOUR_RAZORPAY_KEY` replace કરો

### 4. Build APK
- GitHub Actions → Build APK → Run workflow
